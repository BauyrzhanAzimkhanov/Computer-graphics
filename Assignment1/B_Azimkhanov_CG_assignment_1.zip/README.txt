I only copied the "Putpixel" and "UpdateCanvas" functions.
Because I couldn't find any working suggestions on the Internet.
I wrote the rest.
